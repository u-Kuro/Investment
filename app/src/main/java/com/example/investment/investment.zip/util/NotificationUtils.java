package com.example.investment.util;

import static com.example.investment.service.TickerService.STOP_SERVICE_ACTION;
import static com.example.investment.util.Constants.CHANNEL_ID_SERVICE;
import static com.example.investment.util.Constants.NOTIFICATION_ID_SERVICE;
import static com.example.investment.util.Constants.CHANNEL_NAME_SERVICE;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import com.example.investment.R;
import com.example.investment.service.TickerService;
import com.example.investment.MainActivity;

@RequiresApi(api = Build.VERSION_CODES.O)
public class NotificationUtils {
    public static NotificationCompat.Builder createNotification(
        Context context,
        String channelId,
        String channelName,
        int importance,
        boolean enableVibration
    ) {
        NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
        channel.enableVibration(enableVibration);
        
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);
        
        return new NotificationCompat.Builder(context, channelId).setSmallIcon(R.drawable.logo);
    }
    
    public static PendingIntent createActivityIntent(Context context, Class<?> activityClass) {
        Intent intent = new Intent(context, activityClass);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static Notification createLowPriorityServiceNotification(Context context, String title) {
        NotificationChannel channel = new NotificationChannel(
            CHANNEL_ID_SERVICE,
            CHANNEL_NAME_SERVICE,
            NotificationManager.IMPORTANCE_LOW
        );
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.createNotificationChannel(channel);

        Intent stopIntent = new Intent(context, TickerService.class);
        stopIntent.setAction(STOP_SERVICE_ACTION);
        PendingIntent stopPendingIntent = PendingIntent.getService(
            context, 
            0, 
            stopIntent, 
            PendingIntent.FLAG_CANCEL_CURRENT | PendingIntent.FLAG_MUTABLE
        );

        return new NotificationCompat.Builder(context, CHANNEL_ID_SERVICE)
            .setContentTitle(title)
            .setSmallIcon(R.drawable.logo)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(R.drawable.sync_crossed, "STOP", stopPendingIntent)
            .setVibrate(null)
            .build();
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void showLowPriorityServiceNotification(Context context, String message) {
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.notify(NOTIFICATION_ID_SERVICE, createLowPriorityServiceNotification(context, message));
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public static void showHighPriorityNotification(
        Context context,
        String channelId,
        String channelName,
        String title,
        String content,
        String subtext,
        Long when,
        String groupKey,
        String notificationTag,
        int notificationId
    ) {
        NotificationCompat.Builder builder = createNotification(
            context, 
            channelId,
            channelName,
            NotificationManager.IMPORTANCE_HIGH,
            true
        )
        .setContentTitle(title)
        .setContentText(content)
        .setStyle(
            new NotificationCompat.BigTextStyle()
            .setBigContentTitle(title)
            .bigText(content)
        )
        .setSubText(subtext)
        .setContentIntent(createActivityIntent(context, MainActivity.class))
        .setGroup(groupKey)
        .setGroupSummary(false)
        .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_SUMMARY)
        .setAutoCancel(true);

        if (when != null) {
            builder.setShowWhen(true).setWhen(when);
        }
        
        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.notify(notificationTag, notificationId, builder.build());
    }

    public static void showGroupSummary(
        Context context,
        String channelId,
        String channelName,
        String title,
        String groupKey,
        int notificationId
    ) {
        NotificationCompat.InboxStyle inboxStyle = new NotificationCompat.InboxStyle().setBigContentTitle(title);
        NotificationCompat.Builder builder = createNotification(
            context,
            channelId,
            channelName,
            NotificationManager.IMPORTANCE_HIGH,
            true
        )
        .setContentTitle(title)  // For pre-Nougat only
        .setStyle(inboxStyle)
        .setGroup(groupKey)
        .setGroupSummary(true)
        .setGroupAlertBehavior(NotificationCompat.GROUP_ALERT_SUMMARY)
        .setAutoCancel(false);

        NotificationManager manager = context.getSystemService(NotificationManager.class);
        manager.notify(notificationId, builder.build());
    }
} 